// const express = require('express');
// const app = express();
// const connectDB = require('./config/db');
// const authRoutes = require('./routes/authRoutes');
// const postRoutes = require('./routes/postRoutes');
// const notificationRoutes = require('./routes/notificationRoutes');

// // Database connection
// connectDB();

// // Middleware
// app.use(express.json());

// // Routes
// app.use('/auth', authRoutes);
// app.use('/post', postRoutes);
// app.use('/notification', notificationRoutes);

// module.exports = app;
