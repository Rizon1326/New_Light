const Notification = require('../models/Notification');

const cleanOldNotifications = async () => {
    // Delete notifications older than a specific time
};

module.exports = cleanOldNotifications;
